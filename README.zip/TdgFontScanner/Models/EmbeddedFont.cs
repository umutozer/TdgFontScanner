﻿namespace TdgFontScanner.Models
{
    public class EmbeddedFont
    {
        public string FontName { get; set; }
        public string? FontUrl { get; set; }
    }
}
